import pandas as pd
from datetime import datetime

def analyse(danpindf,pinleidf,pinlei):
    danpinTolist = pinleidf[pinleidf['分类名称'] == pinlei]['单品编码'].tolist()
    cateSales = danpindf[danpindf['单品编码'].isin(danpinTolist)]
    result = (cateSales.groupby(['单品编码', '销售单价(元/千克)'])
              .agg(总销量=('销量(千克)', 'sum'))
              .reset_index()).merge(pinleidf[['单品编码', '单品名称', '分类名称']], on='单品编码', how='left')
    result = result[['分类名称', '单品编码', '单品名称', '销售单价(元/千克)', '总销量']]
    
    return result

if __name__ == "__main__":
    danpinData = pd.read_excel("附件2.xlsx")
    pinleiData = pd.read_excel("附件1.xlsx")
    danpinData['销售日期'] = pd.to_datetime(danpinData['销售日期'])
    print("已读取")
    shaixuanDate = (danpinData['销售日期'] >= "2023-06-01") & (danpinData['销售日期'] <= "2023-06-30")
    filteredDanpin = danpinData.loc[shaixuanDate]
    print("已筛选")
    pinleis = ["花叶类","花菜类","水生根茎类","茄类","辣椒类","食用菌"]
    with pd.ExcelWriter("平均销量定价.xlsx", engine="openpyxl") as writer:  
        for pinlei in pinleis:
            result = analyse(filteredDanpin,pinleiData,pinlei)
            result.to_excel(writer, sheet_name=pinlei, index=False)
            print(f"已完成：{pinlei}")
    print("任务完成")