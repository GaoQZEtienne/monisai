import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei'] 
plt.rcParams['axes.unicode_minus'] = False

file = "销量加成关系.xlsx"  
xls = pd.ExcelFile(file)
count = 0
fig, ax = plt.subplots(2,3,figsize=(15, 10))
for sheet in xls.sheet_names:
    if count == 6:
        break
    df = pd.read_excel(file, sheet_name=sheet)
    x = df.iloc[:, 4]  
    y = df.iloc[:, 3]
    ax[(count // 3),(count % 3)].scatter(x, y,alpha=0.7)
    ax[(count // 3),(count % 3)].set_xlabel(df.columns[4])
    ax[(count // 3),(count % 3)].set_ylabel(df.columns[3])
    ax[(count // 3),(count % 3)].set_xticks(np.arange(x.min(), x.max(), step=0.15))
    ax[(count // 3),(count % 3)].set_title(f"{sheet}")
    ax[(count // 3),(count % 3)].grid(True, linestyle="--", alpha=0.5)
    count += 1
plt.show()
